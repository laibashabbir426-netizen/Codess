/**
 * ==========================================================================
 * AUTOMOTIVE CORE LOGIC PLATFORM - AIR UNIVERSITY MATRIX
 * Handles Theme, Wishlist, Calculations, Search, Analytics & CRUD Mocking
 * ==========================================================================
 */

// Global App Variables & Hardcoded Dataset Matrix
const CAR_REGISTRY = [
    { id: 1, brand: 'Rolls-Royce', model: 'Phantom Coupe', price: 450000, year: 2025, speed: '250 km/h', power: '563 HP', img: 'https://images.unsplash.com/photo-1632245889029-e406faaa34cd?w=600', cat: 'hyper' },
    { id: 2, brand: 'Lamborghini', model: 'Revuelto V12', price: 600000, year: 2026, speed: '350 km/h', power: '1001 HP', img: 'https://images.unsplash.com/photo-1544829099-b9a0c07fad1a?w=600', cat: 'sports' },
    { id: 3, brand: 'Bentley', model: 'Continental GT', price: 300000, year: 2024, speed: '335 km/h', power: '650 HP', img: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=600', cat: 'luxury' },
    { id: 4, brand: 'Ferrari', model: 'SF90 Stradale', price: 520000, year: 2025, speed: '340 km/h', power: '986 HP', img: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?w=600', cat: 'sports' }
];

let appWishlist = JSON.parse(localStorage.getItem('car_wishlist')) || [];
let comparisonTrack = JSON.parse(localStorage.getItem('car_compare')) || [];

document.addEventListener('DOMContentLoaded', () => {
    initializeGlobalUX();
    if (document.getElementById('catalog-grid-space')) mountCatalogEngine();
    if (document.getElementById('comparison-matrix-row')) mountComparisonEngine();
    if (document.getElementById('admin-chart-sales')) renderDashboardCharts();
});

// [UX EXTENSION] Glow Cursor, System Theme Toggle & Counter Animation
function initializeGlobalUX() {
    // Custom Glow Track
    const pointerGlow = document.createElement('div');
    pointerGlow.className = 'cursor-glow-element';
    document.body.appendChild(pointerGlow);
    document.addEventListener('mousemove', (e) => {
        pointerGlow.style.left = e.clientX + 'px';
        pointerGlow.style.top = e.clientY + 'px';
    });

    // Theme Switch Logic
    const savedTheme = localStorage.getItem('app_theme_state') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);

    // Numeric Metrics Rolling System
    document.querySelectorAll('.stat-counter-node').forEach(node => {
        const boundaryVal = parseInt(node.getAttribute('data-target'));
        let stepCount = 0;
        const speedInterval = Math.ceil(boundaryVal / 50);
        const loopTimer = setInterval(() => {
            stepCount += speedInterval;
            if (stepCount >= boundaryVal) {
                node.innerText = boundaryVal.toLocaleString() + "+";
                clearInterval(loopTimer);
            } else {
                node.innerText = stepCount.toLocaleString();
            }
        }, 30);
    });
}

function toggleApplicationTheme() {
    const activeState = document.documentElement.getAttribute('data-theme');
    const targetedState = activeState === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', targetedState);
    localStorage.setItem('app_theme_state', targetedState);
}

// [CATALOG ENGINE] Filter, Search, Lightbox, Wishlist, Compare Hooks
function mountCatalogEngine(categoryFilter = 'all') {
    const gridTarget = document.getElementById('catalog-grid-space');
    if (!gridTarget) return;

    const queryInput = document.getElementById('searchQueryField')?.value.toLowerCase() || "";
    const selectedBrand = document.getElementById('brandFilterField')?.value || "all";
    const selectedPrice = document.getElementById('priceFilterField')?.value || "all";

    gridTarget.innerHTML = "";

    const analyticalDataset = CAR_REGISTRY.filter(item => {
        const matchesCat = categoryFilter === 'all' || item.cat === categoryFilter;
        const matchesQuery = item.brand.toLowerCase().includes(queryInput) || item.model.toLowerCase().includes(queryInput);
        const matchesBrand = selectedBrand === 'all' || item.brand === selectedBrand;
        
        let matchesPrice = true;
        if (selectedPrice === 'low') matchesPrice = item.price <= 400000;
        if (selectedPrice === 'high') matchesPrice = item.price > 400000;

        return matchesCat && matchesQuery && matchesBrand && matchesPrice;
    });

    analyticalDataset.forEach(car => {
        const isFav = appWishlist.includes(car.id) ? 'fa-solid text-danger' : 'fa-regular';
        const isComp = comparisonTrack.includes(car.id) ? 'btn-warning text-dark' : 'btn-outline-warning';

        gridTarget.innerHTML += `
            <div class="col-md-6 col-lg-4">
                <div class="card glass-card p-3 text-white h-100">
                    <img src="${car.img}" class="img-fluid mb-3 w-100 object-fit-cover" style="height:240px; cursor:zoom-in;" onclick="triggerLightboxPopup('${car.img}')">
                    <div class="card-body px-0 py-2 d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start">
                            <h4 class="sub-heading text-white mb-1 fs-5">${car.brand} <span class="normal-text text-muted d-block">${car.model}</span></h4>
                            <button class="btn border-0 p-0 text-warning" onclick="toggleWishlistAction(${car.id})"><i class="${isFav} fa-heart fa-lg"></i></button>
                        </div>
                        <h5 class="normal-text text-warning font-monospace fw-bold mt-2">$${car.price.toLocaleString()}</h5>
                        <div class="d-flex gap-2 mt-4">
                            <button onclick="toggleCompareAction(${car.id})" class="btn btn-sm w-50 btn-typography ${isComp}">⚖️ Compare</button>
                            <a href="#booking" onclick="document.getElementById('preferredVehicleField').value='${car.brand} ${car.model}'" class="btn btn-sm btn-luxury w-50">Book Test Drive</a>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
}

// [LIGHTBOX SYSTEM] Interactive Image Expander Matrix
function triggerLightboxPopup(sourceUri) {
    const lbox = document.getElementById('systemLightboxOverlay');
    const lboxImg = document.getElementById('systemLightboxImage');
    if (!lbox || !lboxImg) return;
    lboxImg.src = sourceUri;
    lbox.style.display = 'flex';
}

function closeLightboxPopup() {
    document.getElementById('systemLightboxOverlay').style.display = 'none';
}

// [WISHLIST LAYER] Local Storage Commit Core
function toggleWishlistAction(id) {
    if (appWishlist.includes(id)) {
        appWishlist = appWishlist.filter(x => x !== id);
    } else {
        appWishlist.push(id);
    }
    localStorage.setItem('car_wishlist', JSON.stringify(appWishlist));
    mountCatalogEngine();
}

// [COMPARE MATRIX CORE] Dual Engine Evaluator Pipeline
function toggleCompareAction(id) {
    if (comparisonTrack.includes(id)) {
        comparisonTrack = comparisonTrack.filter(x => x !== id);
    } else {
        if (comparisonTrack.length >= 2) {
            alert("Comparison matrix accommodates up to 2 vehicle tokens simultaneously.");
            return;
        }
        comparisonTrack.push(id);
    }
    localStorage.setItem('car_compare', JSON.stringify(comparisonTrack));
    mountCatalogEngine();
}

function mountComparisonEngine() {
    const rowAnchor = document.getElementById('comparison-matrix-row');
    if (!rowAnchor) return;
    rowAnchor.innerHTML = "";

    if (comparisonTrack.length === 0) {
        rowAnchor.innerHTML = `<div class="col-12 text-center text-muted normal-text py-5">No vehicle vectors assigned for comparative metrics.</div>`;
        return;
    }

    comparisonTrack.forEach(carId => {
        const car = CAR_REGISTRY.find(x => x.id === carId);
        rowAnchor.innerHTML += `
            <div class="col-md-6">
                <div class="glass-card p-4 text-white text-center">
                    <img src="${car.img}" class="img-fluid mb-3 w-100 object-fit-cover" style="height:250px;">
                    <h3 class="sub-heading text-warning">${car.brand}</h3>
                    <p class="normal-text font-monospace">${car.model}</p>
                    <table class="table table-dark table-striped text-start border border-secondary mt-4">
                        <tr><td>MSRP Benchmark:</td><td class="text-warning">$${car.price.toLocaleString()}</td></tr>
                        <tr><td>Velocity Cap:</td><td>${car.speed}</td></tr>
                        <tr><td>Powertrain Index:</td><td>${car.power}</td></tr>
                        <tr><td>Production Year:</td><td>${car.year}</td></tr>
                    </table>
                    <button class="btn btn-outline-danger btn-sm w-100 mt-3" onclick="toggleCompareAction(${car.id}); mountComparisonEngine();">Remove Vector</button>
                </div>
            </div>
        `;
    });
}

// [FORM COMPLIANCE INTERRUPT] Booking Validation Subroutine
function executeFormBookingSubmit(event) {
    event.preventDefault();
    const targetModel = document.getElementById('preferredVehicleField').value;
    const targetDate = document.getElementById('bookingDateField').value;
    const targetTime = document.getElementById('bookingTimeField').value;

    if (!targetModel || !targetDate || !targetTime) {
        alert("Verification Matrix Failed: Complete all telemetry slots.");
        return;
    }

    alert(`Reservation Dispatched Successfully!\nAsset Pool: ${targetModel}\nNode Schedule: ${targetDate} at ${targetTime}`);
    event.target.reset();
}

// [ADMIN GRAPH DATABASE LAYERS] Mock Core Canvas Rendering Framework
function renderDashboardCharts() {
    const salesCanvas = document.getElementById('admin-chart-sales');
    const metricsCanvas = document.getElementById('admin-chart-metrics');

    if (salesCanvas) {
        salesCanvas.innerHTML = `
            <div class="d-flex align-items-end justify-content-between h-100 pt-4 px-2" style="height: 200px !important;">
                <div class="bg-warning" style="height: 40%; width: 12%;" title="Jan: $1.2M"></div>
                <div class="bg-warning" style="height: 65%; width: 12%;" title="Feb: $2.1M"></div>
                <div class="bg-warning" style="height: 50%; width: 12%;" title="Mar: $1.8M"></div>
                <div class="bg-warning" style="height: 85%; width: 12%;" title="Apr: $3.4M"></div>
                <div class="bg-warning" style="height: 95%; width: 12%;" title="May: $4.2M"></div>
            </div>
            <div class="d-flex justify-content-between border-top border-secondary pt-2 normal-text small text-muted font-monospace">
                <span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span><span>May</span>
            </div>
        `;
    }

    if (metricsCanvas) {
        metricsCanvas.innerHTML = `
            <div class="d-flex align-items-end justify-content-between h-100 pt-4 px-2" style="height: 200px !important;">
                <div class="bg-secondary" style="height: 30%; width: 20%;" title="Sports"></div>
                <div class="bg-warning" style="height: 80%; width: 20%;" title="Luxury"></div>
                <div class="bg-secondary" style="height: 55%; width: 20%;" title="Hyper"></div>
            </div>
            <div class="d-flex justify-content-around border-top border-secondary pt-2 normal-text small text-muted font-monospace">
                <span>Sports</span><span>Luxury</span><span>Hyper</span>
            </div>
        `;
    }
}

// [CRUD LOGIC MODULES] Admin Mock Row Removals
function purgeRegistryItem(rowElementId) {
    if (confirm("Confirm vehicle vector structural deletion?")) {
        document.getElementById(rowElementId)?.remove();
    }
}